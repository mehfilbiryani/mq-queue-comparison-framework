# MQ Compare (Core Services - Maven)

This project contains core services to capture IN/OUT items in DynamoDB and perform comparisons to produce CMP#v1 items.
- No System.out prints; logging via SLF4J/Logback.
- Wire your IBM MQ consumers to call `OutQueueReader.handleMessage(...)` after writing to DynamoDB.
- Configure AWS region via `AWS_REGION` env or `-Daws.region`.

## Build
```
mvn -q -DskipTests package
```
