package com.company.mqcompare.model;

import java.util.List;
import java.util.Map;

public class ProgramRules {
    public String programId;
    public List<String> jsonIgnorePaths;
    public List<String> xmlIgnoreXPaths;
    public Map<String, Double> numericTolerancesByJsonPath;
    public List<String> orderInsensitiveArrayJsonPaths;
}
