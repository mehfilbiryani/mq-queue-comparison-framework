package com.company.mqcompare.service;

import com.company.mqcompare.compare.JsonComparator;
import com.company.mqcompare.compare.XmlComparator;
import com.company.mqcompare.model.CompareResult;
import com.company.mqcompare.model.ProgramRules;
import com.company.mqcompare.repo.DynamoRepository;
import com.company.mqcompare.config.ProgramConfigService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.amazon.awssdk.services.dynamodb.model.QueryResponse;

public class ComparisonOrchestrator {
    private static final Logger log = LoggerFactory.getLogger(ComparisonOrchestrator.class);

    private final DynamoRepository repo;
    private final ProgramConfigService cfg;
    private final JsonComparator jsonComparator = new JsonComparator();
    private final XmlComparator xmlComparator = new XmlComparator();

    public ComparisonOrchestrator(DynamoRepository repo, ProgramConfigService cfg) {
        this.repo = repo;
        this.cfg = cfg;
    }

    public void tryCompare(String programId, String correlationId) {
        QueryResponse qr = repo.getConversation(programId, correlationId);

        String legacyPayload = null, newPayload = null;
        String legacyMsgId = null, newMsgId = null;
        String legacyType = null, newType = null;
        boolean hasCmp = false;

        for (var item : qr.items()) {
            String sk = item.get("SK").s();
            if ("CMP#v1".equals(sk)) { hasCmp = true; }
            else if ("M#OUT#LEGACY".equals(sk)) {
                legacyPayload = item.containsKey("payload") ? item.get("payload").s() : null;
                legacyMsgId = item.containsKey("mqMessageId") ? item.get("mqMessageId").s() : null;
                legacyType = item.containsKey("payloadType") ? item.get("payloadType").s() : "TEXT";
            } else if ("M#OUT#NEW".equals(sk)) {
                newPayload = item.containsKey("payload") ? item.get("payload").s() : null;
                newMsgId = item.containsKey("mqMessageId") ? item.get("mqMessageId").s() : null;
                newType = item.containsKey("payloadType") ? item.get("payloadType").s() : "TEXT";
            }
        }

        if (hasCmp) return;
        if (legacyPayload == null || newPayload == null) return;

        ProgramRules rules = cfg.get(programId);
        CompareResult result;
        try {
            if ("JSON".equalsIgnoreCase(legacyType) && "JSON".equalsIgnoreCase(newType)) {
                result = jsonComparator.compare(programId, correlationId, legacyPayload, newPayload, legacyMsgId, newMsgId, rules);
            } else if ("XML".equalsIgnoreCase(legacyType) && "XML".equalsIgnoreCase(newType)) {
                result = xmlComparator.compare(programId, correlationId, legacyPayload, newPayload, legacyMsgId, newMsgId, rules);
            } else {
                // fall back to string compare
                result = new CompareResult();
                result.programId = programId;
                result.correlationId = correlationId;
                result.legacyMessageId = legacyMsgId;
                result.newMessageId = newMsgId;
                result.arrivedAtTs = System.currentTimeMillis();
                if ((legacyPayload == null ? "" : legacyPayload).equals(newPayload == null ? "" : newPayload)) {
                    result.status = CompareResult.Status.MATCH;
                    result.diffSummary = "-";
                } else {
                    result.status = CompareResult.Status.MISMATCH;
                    result.diffSummary = "Plain text mismatch";
                }
            }
        } catch (Exception ex) {
            result = new CompareResult();
            result.programId = programId;
            result.correlationId = correlationId;
            result.legacyMessageId = legacyMsgId;
            result.newMessageId = newMsgId;
            result.arrivedAtTs = System.currentTimeMillis();
            result.status = CompareResult.Status.ERROR;
            result.diffSummary = ex.getClass().getSimpleName() + ": " + ex.getMessage();
        }

        repo.putComparisonOnce(programId, correlationId, result);
    }
}
