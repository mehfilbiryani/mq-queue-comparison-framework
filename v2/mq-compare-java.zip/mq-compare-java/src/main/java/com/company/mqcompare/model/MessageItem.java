package com.company.mqcompare.model;

public class MessageItem {
    public enum Source { IN, OUT_LEGACY, OUT_NEW }
    public enum PayloadType { JSON, XML, TEXT }

    public String programId;
    public String correlationId;
    public Source source;
    public String mqMessageId; // for OUTs
    public PayloadType payloadType;
    public String payload;     // or s3Uri if large
    public String s3Uri;
    public String contentHash;
    public long arrivedAtTs;

    public static boolean isOutLegacy(String sk) { return "M#OUT#LEGACY".equals(sk); }
    public static boolean isOutNew(String sk)     { return "M#OUT#NEW".equals(sk); }
}
