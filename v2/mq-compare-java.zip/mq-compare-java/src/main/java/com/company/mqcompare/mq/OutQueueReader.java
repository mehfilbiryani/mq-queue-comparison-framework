package com.company.mqcompare.mq;

import com.company.mqcompare.repo.DynamoRepository;
import com.company.mqcompare.service.ComparisonOrchestrator;

public class OutQueueReader {
    private final DynamoRepository repo;
    private final ComparisonOrchestrator orchestrator;
    private final String programId;
    private final String sourceSk; // "M#OUT#LEGACY" or "M#OUT#NEW"

    public OutQueueReader(DynamoRepository repo, ComparisonOrchestrator orchestrator, String programId, String sourceSk) {
        this.repo = repo;
        this.orchestrator = orchestrator;
        this.programId = programId;
        this.sourceSk = sourceSk;
    }

    // You would call this method when a message arrives from MQ.
    public void handleMessage(String correlationId, String mqMessageId, String payloadType, String payload, long ts, String hash) {
        repo.putOutIdempotent(programId, correlationId, sourceSk, mqMessageId, payloadType, payload, ts, hash);
        orchestrator.tryCompare(programId, correlationId);
    }
}
