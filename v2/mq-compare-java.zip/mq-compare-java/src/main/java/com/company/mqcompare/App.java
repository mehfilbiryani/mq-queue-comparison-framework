package com.company.mqcompare;

import com.company.mqcompare.service.ComparisonOrchestrator;
import com.company.mqcompare.repo.DynamoRepository;
import com.company.mqcompare.config.ProgramConfigService;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Entry class (no console prints). Wires core services; users can integrate readers or lambdas.
 */
public class App {
    private static final Logger log = LoggerFactory.getLogger(App.class);

    public static void main(String[] args) {
        // Intentionally minimal; no System.out. This wires core services for embedding in your runtime.
        DynamoDbClient ddb = DynamoRepository.defaultClient();
        var repo = new DynamoRepository(ddb, "mq_compare");
        var cfg  = new ProgramConfigService("program_config", ddb);
        var orchestrator = new ComparisonOrchestrator(repo, cfg);

        // Example of how you might call tryCompare in your reader after writing an OUT:
        // orchestrator.tryCompare("claims", "abc123");
        log.info("MQ Compare core services initialized.");
    }
}
