package com.company.mqcompare.repo;

import com.company.mqcompare.model.CompareResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.amazon.awssdk.core.client.config.ClientOverrideConfiguration;
import software.amazon.awssdk.core.retry.backoff.EqualJitterBackoffStrategy;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;
import software.amazon.awssdk.regions.Region;

import java.time.Duration;
import java.util.List;
import java.util.Map;

public class DynamoRepository {
    private static final Logger log = LoggerFactory.getLogger(DynamoRepository.class);
    private final DynamoDbClient ddb;
    private final String table;

    public DynamoRepository(DynamoDbClient ddb, String table) {
        this.ddb = ddb;
        this.table = table;
    }

    public static DynamoDbClient defaultClient() {
        return DynamoDbClient.builder()
                .region(Region.of(System.getProperty("aws.region", System.getenv().getOrDefault("AWS_REGION", "ap-south-1"))))
                .overrideConfiguration(ClientOverrideConfiguration.builder()
                        .apiCallTimeout(Duration.ofSeconds(10))
                        .apiCallAttemptTimeout(Duration.ofSeconds(5))
                        .retryPolicy(b -> b
                                .numRetries(8)
                                .backoffStrategy(EqualJitterBackoffStrategy.builder()
                                        .baseDelay(Duration.ofMillis(100))
                                        .maxBackoffTime(Duration.ofSeconds(5)).build()))
                        .build())
                .build();
    }

    private static AttributeValue s(String v){ return AttributeValue.builder().s(v).build(); }
    private static AttributeValue n(long v){ return AttributeValue.builder().n(Long.toString(v)).build(); }

    public void putInOnce(String programId, String corrId, String payloadType, String payload, long ts, String contentHash) {
        String pk = "P#" + programId + "#C#" + corrId;
        PutItemRequest req = PutItemRequest.builder()
                .tableName(table)
                .item(Map.of(
                        "PK", s(pk),
                        "SK", s("M#IN"),
                        "programId", s(programId),
                        "correlationId", s(corrId),
                        "source", s("IN"),
                        "payloadType", s(payloadType),
                        "payload", s(payload),
                        "contentHash", s(contentHash),
                        "arrivedAtTs", n(ts),
                        "GSI1PK", s("P#" + programId),
                        "GSI1SK", n(ts)
                ))
                .conditionExpression("attribute_not_exists(PK) AND attribute_not_exists(SK)")
                .build();
        ddb.putItem(req);
    }

    public boolean putOutIdempotent(String programId, String corrId, String sourceSk, String mqMessageId, String payloadType, String payload, long ts, String contentHash) {
        String pk = "P#" + programId + "#C#" + corrId;
        try {
            ddb.putItem(PutItemRequest.builder()
                    .tableName(table)
                    .item(Map.of(
                            "PK", s(pk),
                            "SK", s(sourceSk),
                            "programId", s(programId),
                            "correlationId", s(corrId),
                            "source", s(sourceSk.equals("M#OUT#LEGACY") ? "OUT_LEGACY" : "OUT_NEW"),
                            "mqMessageId", s(mqMessageId),
                            "payloadType", s(payloadType),
                            "payload", s(payload),
                            "contentHash", s(contentHash),
                            "arrivedAtTs", n(ts),
                            "GSI1PK", s("P#" + programId),
                            "GSI1SK", n(ts),
                            "GSI3PK", s(mqMessageId),
                            "GSI3SK", s(programId)
                    ))
                    .conditionExpression("attribute_not_exists(PK) OR contentHash <> :h")
                    .expressionAttributeValues(Map.of(":h", s(contentHash)))
                    .build());
            return true;
        } catch (ConditionalCheckFailedException e) {
            return false;
        }
    }

    public boolean putComparisonOnce(String programId, String corrId, CompareResult result) {
        String pk = "P#" + programId + "#C#" + corrId;
        try {
            ddb.putItem(PutItemRequest.builder()
                    .tableName(table)
                    .item(Map.of(
                            "PK", s(pk),
                            "SK", s("CMP#v1"),
                            "programId", s(programId),
                            "correlationId", s(corrId),
                            "status", s(result.status.name()),
                            "diffSummary", s(result.diffSummary == null ? "-" : result.diffSummary),
                            "diffDetails", s(result.diffDetails == null ? "" : result.diffDetails),
                            "arrivedAtTs", n(result.arrivedAtTs),
                            "legacyMessageId", s(result.legacyMessageId == null ? "" : result.legacyMessageId),
                            "newMessageId", s(result.newMessageId == null ? "" : result.newMessageId),
                            "GSI2PK", s(result.status.name()),
                            "GSI2SK", n(result.arrivedAtTs)
                    ))
                    .conditionExpression("attribute_not_exists(PK) AND attribute_not_exists(SK)")
                    .build());
            return true;
        } catch (ConditionalCheckFailedException e) {
            return false;
        }
    }

    public QueryResponse getConversation(String programId, String corrId) {
        String pk = "P#" + programId + "#C#" + corrId;
        return ddb.query(QueryRequest.builder()
                .tableName(table)
                .keyConditionExpression("PK = :pk")
                .expressionAttributeValues(Map.of(":pk", s(pk)))
                .build());
    }
}
