package com.company.mqcompare.config;

import com.company.mqcompare.model.ProgramRules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

/**
 * Loads per-program comparison rules. For brevity, returns defaults; extend to read from program_config.
 */
public class ProgramConfigService {
    private static final Logger log = LoggerFactory.getLogger(ProgramConfigService.class);
    private final String tableName;
    private final DynamoDbClient ddb;

    public ProgramConfigService(String tableName, DynamoDbClient ddb) {
        this.tableName = tableName;
        this.ddb = ddb;
    }

    public ProgramRules get(String programId) {
        ProgramRules r = new ProgramRules();
        r.programId = programId;
        // Provide sane defaults; teams can populate program_config and extend this.
        r.jsonIgnorePaths = java.util.List.of("$.header.timestamp", "$..requestId");
        r.xmlIgnoreXPaths = java.util.List.of("//Header/Timestamp", "//Header/RequestId");
        r.numericTolerancesByJsonPath = java.util.Map.of();
        r.orderInsensitiveArrayJsonPaths = java.util.List.of();
        return r;
    }
}
