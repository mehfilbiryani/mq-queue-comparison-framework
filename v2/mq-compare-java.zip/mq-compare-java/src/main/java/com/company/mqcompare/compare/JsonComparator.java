package com.company.mqcompare.compare;

import com.company.mqcompare.model.CompareResult;
import com.company.mqcompare.model.ProgramRules;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;

public class JsonComparator implements MessageComparator {
    private static final ObjectMapper M = new ObjectMapper();

    @Override
    public CompareResult compare(String programId, String correlationId,
                                 String legacyPayload, String newPayload,
                                 String legacyMsgId, String newMsgId,
                                 ProgramRules rules) throws Exception {
        long start = System.currentTimeMillis();
        CompareResult out = new CompareResult();
        out.programId = programId;
        out.correlationId = correlationId;
        out.legacyMessageId = legacyMsgId;
        out.newMessageId = newMsgId;
        out.arrivedAtTs = System.currentTimeMillis();

        try {
            JsonNode a = M.readTree(legacyPayload);
            JsonNode b = M.readTree(newPayload);

            // Apply ignore paths (very simple remover for dot/JSONPath-like paths)
            if (rules.jsonIgnorePaths != null) {
                for (String p : rules.jsonIgnorePaths) {
                    a = JsonPathUtil.removePath(a, p);
                    b = JsonPathUtil.removePath(b, p);
                }
            }

            List<String> diffs = new ArrayList<>();
            deepCompare("$", a, b, diffs, rules);
            if (diffs.isEmpty()) {
                out.status = CompareResult.Status.MATCH;
                out.diffSummary = "-";
                out.diffDetails = "";
            } else {
                out.status = CompareResult.Status.MISMATCH;
                out.diffSummary = diffs.size() + " differences";
                out.diffDetails = String.join("\n", diffs);
            }
        } catch (Exception ex) {
            out.status = CompareResult.Status.ERROR;
            out.diffSummary = ex.getClass().getSimpleName() + ": " + ex.getMessage();
            out.diffDetails = "";
        } finally {
            out.compareLatencyMs = System.currentTimeMillis() - start;
        }
        return out;
    }

    private void deepCompare(String path, JsonNode a, JsonNode b, List<String> diffs, ProgramRules rules) {
        if (Objects.equals(a, b)) return;

        if (a == null || b == null) {
            diffs.add(path + " one side is null");
            return;
        }
        if (a.isObject() && b.isObject()) {
            var an = a.fieldNames();
            Set<String> keys = new TreeSet<>();
            while (an.hasNext()) keys.add(an.next());
            var bn = b.fieldNames();
            while (bn.hasNext()) keys.add(bn.next());
            for (String k : keys) {
                deepCompare(path + "." + k, a.get(k), b.get(k), diffs, rules);
            }
        } else if (a.isArray() && b.isArray()) {
            // naive order-sensitive compare; teams can extend to order-insensitive by path
            int max = Math.max(a.size(), b.size());
            for (int i = 0; i < max; i++) {
                deepCompare(path + "[" + i + "]", a.get(i), b.get(i), diffs, rules);
            }
        } else if (a.isNumber() && b.isNumber()) {
            double av = a.asDouble();
            double bv = b.asDouble();
            double tol = 0.0;
            if (rules.numericTolerancesByJsonPath != null) {
                tol = rules.numericTolerancesByJsonPath.getOrDefault(path, 0.0);
            }
            if (Math.abs(av - bv) > tol) {
                diffs.add(path + " number differ: " + av + " vs " + bv + " (tol " + tol + ")");
            }
        } else {
            if (!a.asText("").equals(b.asText(""))) {
                diffs.add(path + " differ: '" + a.asText("") + "' vs '" + b.asText("") + "'");
            }
        }
    }

    /** Minimal path remover that handles simple '$.a.b' style. Extend as needed. */
    static class JsonPathUtil {
        static JsonNode removePath(JsonNode node, String path) {
            if (node == null || path == null) return node;
            if (!path.startsWith("$.")) return node;
            String[] parts = path.substring(2).split("\.");
            return remove(node.deepCopy(), parts, 0);
        }
        private static JsonNode remove(JsonNode node, String[] parts, int i) {
            if (i >= parts.length) return node;
            String p = parts[i];
            if (node.has(p)) {
                if (i == parts.length - 1) {
                    ((com.fasterxml.jackson.databind.node.ObjectNode) node).remove(p);
                } else {
                    remove(node.get(p), parts, i + 1);
                }
            }
            return node;
        }
    }
}
