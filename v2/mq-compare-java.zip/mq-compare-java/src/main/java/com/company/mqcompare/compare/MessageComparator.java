package com.company.mqcompare.compare;

import com.company.mqcompare.model.CompareResult;
import com.company.mqcompare.model.ProgramRules;

public interface MessageComparator {
    CompareResult compare(String programId, String correlationId,
                          String legacyPayload, String newPayload,
                          String legacyMsgId, String newMsgId,
                          ProgramRules rules) throws Exception;
}
