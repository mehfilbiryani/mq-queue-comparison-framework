package com.company.mqcompare.model;

import java.util.List;

public class CompareResult {
    public enum Status { MATCH, MISMATCH, PARTIAL, ERROR, TIMEOUT }

    public String programId;
    public String correlationId;
    public Status status;
    public String diffSummary;
    public String diffDetails; // could be JSON or an S3 URI
    public List<String> ignoredPathsApplied;
    public long compareLatencyMs;
    public String legacyMessageId;
    public String newMessageId;
    public long arrivedAtTs;
}
