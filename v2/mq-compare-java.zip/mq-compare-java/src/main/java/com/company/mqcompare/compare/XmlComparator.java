package com.company.mqcompare.compare;

import com.company.mqcompare.model.CompareResult;
import com.company.mqcompare.model.ProgramRules;
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.diff.Diff;
import org.xmlunit.builder.Input;

public class XmlComparator implements MessageComparator {
    @Override
    public CompareResult compare(String programId, String correlationId,
                                 String legacyPayload, String newPayload,
                                 String legacyMsgId, String newMsgId,
                                 ProgramRules rules) throws Exception {
        long start = System.currentTimeMillis();
        CompareResult out = new CompareResult();
        out.programId = programId;
        out.correlationId = correlationId;
        out.legacyMessageId = legacyMsgId;
        out.newMessageId = newMsgId;
        out.arrivedAtTs = System.currentTimeMillis();
        try {
            var builder = DiffBuilder.compare(Input.fromString(legacyPayload))
                    .withTest(Input.fromString(newPayload))
                    .ignoreWhitespace()
                    .ignoreComments()
                    .checkForSimilar();

            // NOTE: XMLUnit doesn't directly ignore XPaths without custom DifferenceEvaluators;
            // for brevity, we only set baseline options here.
            Diff diff = builder.build();
            if (!diff.hasDifferences()) {
                out.status = CompareResult.Status.MATCH;
                out.diffSummary = "-";
                out.diffDetails = "";
            } else {
                out.status = CompareResult.Status.MISMATCH;
                StringBuilder sb = new StringBuilder();
                diff.getDifferences().forEach(d -> sb.append(d.toString()).append("\n"));
                out.diffDetails = sb.toString();
                out.diffSummary = "XML differences present";
            }
        } catch (Exception ex) {
            out.status = CompareResult.Status.ERROR;
            out.diffSummary = ex.getClass().getSimpleName() + ": " + ex.getMessage();
            out.diffDetails = "";
        } finally {
            out.compareLatencyMs = System.currentTimeMillis() - start;
        }
        return out;
    }
}
