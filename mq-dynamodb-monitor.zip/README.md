# MQ DynamoDB Monitor

A Spring Boot service that continuously scans a DynamoDB table of MQ messages, compares JSON/XML payloads with ignore rules, generates Extent HTML reports, optionally uploads to S3, and sends notifications via Email and Microsoft Teams.

## Build & Run

```bash
mvn clean package
java -jar target/mq-dynamodb-monitor-1.0.0.jar
```

Configure `src/main/resources/application.properties` before running.

## Configuration

- DynamoDB tables: `app.dynamo-table`, `app.processed-table`
- AWS region: `app.aws-region`
- Ignore rules:
  - JSON paths: `app.ignore-fields` (e.g., `metadata.*,timestamp,header.requestId`)
  - XML XPaths: `app.ignore-xml-xpaths`
- Scheduler cron: `app.cron`
- Reporting directory: `app.report-dir`
- S3 upload: `app.s3-upload-enabled`, `app.s3-bucket`, `app.s3-prefix`, `app.s3-public-url`, `app.s3-presign-minutes`
- Email: `app.email-enabled`, `app.email-recipients` plus Spring Mail SMTP settings
- Teams: `app.teams-enabled`, `app.teams-webhook-url`

## Notes

- Processed messages are tracked by `ProcessedTracker` keyed by `correlationid`.
- All comparison/parse errors are written to the Extent report.
- The scheduled job is fully wrapped in try/catch to avoid crashes.
