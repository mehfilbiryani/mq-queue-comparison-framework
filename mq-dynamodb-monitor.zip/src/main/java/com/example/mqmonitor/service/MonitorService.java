package com.example.mqmonitor.service;

import com.aventstack.extentreports.ExtentReports;
import com.example.mqmonitor.aws.DynamoService;
import com.example.mqmonitor.aws.S3Service;
import com.example.mqmonitor.compare.MessageComparator;
import com.example.mqmonitor.config.AppProperties;
import com.example.mqmonitor.model.ComparisonResult;
import com.example.mqmonitor.model.MQMessageItem;
import com.example.mqmonitor.notify.EmailService;
import com.example.mqmonitor.notify.TeamsNotifier;
import com.example.mqmonitor.reporting.ReportService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.dynamodb.model.ResourceNotFoundException;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class MonitorService {
    private static final Logger log = LoggerFactory.getLogger(MonitorService.class);

    private final AppProperties props;
    private final DynamoService dynamoService;
    private final MessageComparator comparator;
    private final ReportService reportService;
    private final S3Service s3Service;
    private final EmailService emailService;
    private final TeamsNotifier teamsNotifier;

    public MonitorService(AppProperties props,
                          DynamoService dynamoService,
                          MessageComparator comparator,
                          ReportService reportService,
                          S3Service s3Service,
                          EmailService emailService,
                          TeamsNotifier teamsNotifier) {
        this.props = props;
        this.dynamoService = dynamoService;
        this.comparator = comparator;
        this.reportService = reportService;
        this.s3Service = s3Service;
        this.emailService = emailService;
        this.teamsNotifier = teamsNotifier;
    }

    @Scheduled(cron = "#{@appProperties.cron}")
    public void run() {
        try {
            log.info("Starting scheduled MQ monitor run");
            StringBuilder fnameHolder = new StringBuilder();
            ExtentReports extent = reportService.create(fnameHolder);

            AtomicInteger mismatchCount = new AtomicInteger(0);
            AtomicInteger errorCount = new AtomicInteger(0);
            AtomicInteger matchCount = new AtomicInteger(0);

            List<MQMessageItem> batch;
            try {
                batch = dynamoService.scanUnprocessedBatch(null);
            } catch (ResourceNotFoundException rnfe) {
                String msg = "DynamoDB table not found: " + props.getDynamoTable();
                log.error(msg);
                reportService.logError(extent, "DynamoDB", msg);
                reportService.finalizeReport(extent, fnameHolder.toString());
                return;
            } catch (Exception e) {
                String msg = "DynamoDB scan error: " + e.getMessage();
                log.warn(msg);
                reportService.logError(extent, "DynamoDB", msg);
                reportService.finalizeReport(extent, fnameHolder.toString());
                return;
            }

            for (MQMessageItem item : batch) {
                if (item == null) {
                    reportService.logError(extent, "Item", "Malformed or null item skipped");
                    errorCount.incrementAndGet();
                    continue;
                }
                ComparisonResult cr = comparator.compare(item.getMessage1(), item.getMessage2());
                switch (cr.getStatus()) {
                    case MATCH -> matchCount.incrementAndGet();
                    case MISMATCH -> mismatchCount.incrementAndGet();
                    case ERROR -> errorCount.incrementAndGet();
                }
                reportService.logRecord(extent, item, cr);
                if (cr.getStatus() != ComparisonResult.Status.ERROR) {
                    dynamoService.markProcessed(item.getCorrelationid());
                }
            }

            var res = reportService.finalizeReport(extent, fnameHolder.toString());
            String s3Url = null;
            if (props.isS3UploadEnabled()) {
                String key = props.getS3Prefix() + res.filename;
                s3Url = s3Service.uploadReport(new java.io.File(props.getReportDir(), res.filename), key);
                if (s3Url == null) {
                    log.warn("S3 upload failed; continuing with local report");
                }
            }

            if (props.isEmailEnabled()) {
                emailService.sendReport(new java.io.File(props.getReportDir(), res.filename), "MQ Comparison Report: " + res.filename);
            }

            if (props.isTeamsEnabled() && mismatchCount.get() > 0) {
                String link = (s3Url != null) ? s3Url : new java.io.File(props.getReportDir(), res.filename).getAbsolutePath();
                String text = String.format("MQ comparison completed. Mismatches: %d, Errors: %d, Matches: %d. Report: %s",
                        mismatchCount.get(), errorCount.get(), matchCount.get(), link);
                teamsNotifier.sendMismatchAlert(text);
            }

            log.info("Run complete. Matches: {}, Mismatches: {}, Errors: {}", matchCount.get(), mismatchCount.get(), errorCount.get());
        } catch (Exception e) {
            log.error("Uncaught exception in scheduled run", e);
        }
    }
}
