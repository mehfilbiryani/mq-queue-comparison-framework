package com.example.mqmonitor.notify;

import com.example.mqmonitor.config.AppProperties;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;

@Service
public class TeamsNotifier {
    private static final Logger log = LoggerFactory.getLogger(TeamsNotifier.class);
    private final AppProperties props;

    public TeamsNotifier(AppProperties props) { this.props = props; }

    public void sendMismatchAlert(String messageText) {
        if (!props.isTeamsEnabled()) return;
        if (props.getTeamsWebhookUrl() == null || props.getTeamsWebhookUrl().isBlank()) {
            log.warn("Teams is enabled but webhook URL missing");
            return;
        }
        try {
            HttpClient client = HttpClients.createDefault();
            HttpPost post = new HttpPost(props.getTeamsWebhookUrl());
            String payload = "{\"text\": \"" + messageText.replace("\"","'") + "\"}";
            post.setEntity(new StringEntity(payload, StandardCharsets.UTF_8));
            post.setHeader("Content-Type", "application/json");
            client.execute(post).close();
        } catch (Exception e) {
            log.warn("Teams webhook failed: {}", e.getMessage());
        }
    }
}
