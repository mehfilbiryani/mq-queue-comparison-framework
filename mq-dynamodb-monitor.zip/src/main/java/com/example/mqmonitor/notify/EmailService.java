package com.example.mqmonitor.notify;

import com.example.mqmonitor.config.AppProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.internet.MimeMessage;
import java.io.File;

@Service
public class EmailService {
    private static final Logger log = LoggerFactory.getLogger(EmailService.class);
    private final JavaMailSender mailSender;
    private final AppProperties props;

    public EmailService(JavaMailSender mailSender, AppProperties props) {
        this.mailSender = mailSender;
        this.props = props;
    }

    public void sendReport(File report, String subject) {
        if (!props.isEmailEnabled()) return;
        if (props.getEmailRecipients() == null || props.getEmailRecipients().isEmpty()) {
            log.warn("Email is enabled but no recipients configured");
            return;
        }
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setSubject(subject);
            helper.setText("Please find the MQ comparison report attached.");
            helper.setTo(props.getEmailRecipients().toArray(new String[0]));
            helper.addAttachment(report.getName(), new FileSystemResource(report));
            mailSender.send(message);
        } catch (MailException | jakarta.mail.MessagingException e) {
            log.warn("Failed to send email: {}", e.getMessage());
        }
    }
}
