package com.example.mqmonitor.compare;

import com.example.mqmonitor.model.ComparisonResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class JsonComparator {
    private static final Logger log = LoggerFactory.getLogger(JsonComparator.class);
    private final ObjectMapper mapper = new ObjectMapper();

    public ComparisonResult compareJson(String a, String b, java.util.List<String> ignoreFields) {
        try {
            JsonNode ja = mapper.readTree(a);
            JsonNode jb = mapper.readTree(b);

            Set<String> ignore = new HashSet<>();
            if (ignoreFields != null) ignore.addAll(ignoreFields);

            List<String> diffs = new ArrayList<>();
            compareNode("", ja, jb, ignore, diffs);

            if (diffs.isEmpty()) return ComparisonResult.match();
            return ComparisonResult.mismatch(String.join("\n", diffs));
        } catch (JsonProcessingException jpe) {
            String msg = "Malformed JSON: " + jpe.getOriginalMessage();
            log.warn(msg);
            return ComparisonResult.error(msg);
        } catch (Exception e) {
            log.error("JSON comparison failure", e);
            return ComparisonResult.error("JSON comparison failure: " + e.getMessage());
        }
    }

    private void compareNode(String path, JsonNode a, JsonNode b, Set<String> ignore, List<String> diffs) {
        if (a == null && b == null) return;
        if (a == null || b == null) {
            diffs.add(String.format("%s: one is null, other not", path));
            return;
        }

        if (a.isObject() && b.isObject()) {
            Set<String> keys = new TreeSet<>();
            a.fieldNames().forEachRemaining(keys::add);
            b.fieldNames().forEachRemaining(keys::add);

            for (String k : keys) {
                String childPath = path.isEmpty() ? k : path + "." + k;
                if (shouldIgnore(childPath, ignore)) continue;
                JsonNode va = a.get(k);
                JsonNode vb = b.get(k);
                compareNode(childPath, va, vb, ignore, diffs);
            }
        } else if (a.isArray() && b.isArray()) {
            int max = Math.max(a.size(), b.size());
            for (int i = 0; i < max; i++) {
                String childPath = path + "[" + i + "]";
                if (shouldIgnore(childPath, ignore)) continue;
                JsonNode va = i < a.size() ? a.get(i) : null;
                JsonNode vb = i < b.size() ? b.get(i) : null;
                compareNode(childPath, va, vb, ignore, diffs);
            }
        } else {
            if (!Objects.equals(a.asText(), b.asText())) {
                diffs.add(String.format("%s: '%s' != '%s'", path, a.asText(), b.asText()));
            }
        }
    }

    private boolean shouldIgnore(String path, Set<String> ignore) {
        for (String patt : ignore) {
            if (patt == null) continue;
            String p = patt.trim();
            if (p.isEmpty()) continue;
            if (p.equalsIgnoreCase(path)) return true;
            if (p.endsWith(".*")) {
                String prefix = p.substring(0, p.length()-2);
                if (path.equals(prefix) || path.startsWith(prefix + ".")) return true;
            }
        }
        return false;
    }
}
