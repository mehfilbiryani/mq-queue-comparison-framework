package com.example.mqmonitor.compare;

import com.example.mqmonitor.model.ComparisonResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.diff.*;

import java.util.List;

@Component
public class XmlComparator {
    private static final Logger log = LoggerFactory.getLogger(XmlComparator.class);

    public ComparisonResult compareXml(String a, String b, List<String> ignoreXpaths) {
        try {
            DifferenceEvaluator evaluator = DifferenceEvaluators.chain(
                    DifferenceEvaluators.Default,
                    (comparison, outcome) -> {
                        if (outcome == ComparisonResult.DIFFERENT && ignoreXpaths != null) {
                            String xPath = comparison.getTestDetails().getXPath();
                            if (xPath == null) xPath = comparison.getControlDetails().getXPath();
                            if (xPath != null) {
                                for (String ign : ignoreXpaths) {
                                    if (xPath.startsWith(ign)) {
                                        return ComparisonResult.EQUAL;
                                    }
                                }
                            }
                        }
                        return outcome;
                    });

            org.xmlunit.diff.Diff diff = DiffBuilder.compare(a)
                    .withTest(b)
                    .ignoreComments()
                    .ignoreWhitespace()
                    .withDifferenceEvaluator(evaluator)
                    .checkForSimilar()
                    .build();

            if (!diff.hasDifferences()) {
                return ComparisonResult.match();
            } else {
                StringBuilder sb = new StringBuilder();
                diff.getDifferences().forEach(d -> sb.append(d.toString()).append("\n"));
                return ComparisonResult.mismatch(sb.toString());
            }
        } catch (Exception e) {
            log.warn("XML parsing/comparison error: {}", e.getMessage());
            return ComparisonResult.error("Malformed XML or comparison error: " + e.getMessage());
        }
    }
}
