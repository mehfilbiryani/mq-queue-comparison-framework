package com.example.mqmonitor.compare;

import com.example.mqmonitor.config.AppProperties;
import com.example.mqmonitor.model.ComparisonResult;
import com.example.mqmonitor.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class MessageComparator {
    private static final Logger log = LoggerFactory.getLogger(MessageComparator.class);
    private final JsonComparator jsonComparator;
    private final XmlComparator xmlComparator;
    private final AppProperties props;

    public MessageComparator(JsonComparator jsonComparator, XmlComparator xmlComparator, AppProperties props) {
        this.jsonComparator = jsonComparator;
        this.xmlComparator = xmlComparator;
        this.props = props;
    }

    public ComparisonResult compare(String a, String b) {
        try {
            if (Utils.looksLikeJson(a) && Utils.looksLikeJson(b)) {
                return jsonComparator.compareJson(a, b, props.getIgnoreFields());
            } else if (Utils.looksLikeXml(a) && Utils.looksLikeXml(b)) {
                return xmlComparator.compareXml(a, b, props.getIgnoreXmlXpaths());
            } else {
                return ComparisonResult.error("Message types differ or unrecognized (JSON vs XML).");
            }
        } catch (Exception ex) {
            log.error("Unexpected comparison error", ex);
            return ComparisonResult.error("Unexpected error: " + ex.getMessage());
        }
    }
}
