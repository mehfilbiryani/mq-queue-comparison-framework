package com.example.mqmonitor.aws;

import com.example.mqmonitor.config.AppProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

import java.io.File;
import java.time.Duration;

@Service
public class S3Service {
    private static final Logger log = LoggerFactory.getLogger(S3Service.class);
    private final AppProperties props;

    public S3Service(AppProperties props) { this.props = props; }

    private S3Client client() {
        return S3Client.builder()
                .region(Region.of(props.getAwsRegion()))
                .credentialsProvider(DefaultCredentialsProvider.create())
                .build();
    }

    public String uploadReport(File file, String key) {
        try (S3Client s3 = client()) {
            PutObjectRequest req = PutObjectRequest.builder()
                    .bucket(props.getS3Bucket())
                    .key(key)
                    .contentType("text/html")
                    .build();
            s3.putObject(req, file.toPath());

            if (props.isS3PublicUrl()) {
                return String.format("https://%s.s3.%s.amazonaws.com/%s",
                        props.getS3Bucket(), props.getAwsRegion(), key);
            } else {
                try (S3Presigner presigner = S3Presigner.builder()
                        .region(software.amazon.awssdk.regions.Region.of(props.getAwsRegion()))
                        .credentialsProvider(DefaultCredentialsProvider.create())
                        .build()) {
                    GetObjectRequest gor = GetObjectRequest.builder()
                            .bucket(props.getS3Bucket()).key(key).build();
                    GetObjectPresignRequest preq = GetObjectPresignRequest.builder()
                            .signatureDuration(Duration.ofMinutes(props.getS3PresignMinutes()))
                            .getObjectRequest(gor).build();
                    PresignedGetObjectRequest presigned = presigner.presignGetObject(preq);
                    return presigned.url().toString();
                }
            }
        } catch (NoSuchBucketException nb) {
            log.error("S3 bucket not found: {}", props.getS3Bucket());
            return null;
        } catch (S3Exception s3e) {
            log.warn("S3 error: {}", s3e.getMessage());
            return null;
        } catch (Exception e) {
            log.warn("S3 upload failed: {}", e.getMessage());
            return null;
        }
    }
}
