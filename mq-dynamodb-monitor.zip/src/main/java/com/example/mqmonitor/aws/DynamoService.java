package com.example.mqmonitor.aws;

import com.example.mqmonitor.config.AppProperties;
import com.example.mqmonitor.model.MQMessageItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import java.util.*;

@Service
public class DynamoService {
    private static final Logger log = LoggerFactory.getLogger(DynamoService.class);
    private final AppProperties props;

    public DynamoService(AppProperties props) {
        this.props = props;
    }

    private DynamoDbClient client() {
        return DynamoDbClient.builder()
                .region(Region.of(props.getAwsRegion()))
                .credentialsProvider(DefaultCredentialsProvider.create())
                .build();
    }

    public List<MQMessageItem> scanUnprocessedBatch(String lastEvaluatedKey) throws ResourceNotFoundException {
        try (DynamoDbClient db = client()) {
            ScanRequest req = ScanRequest.builder()
                    .tableName(props.getDynamoTable())
                    .limit(props.getDynamoPageSize())
                    .build();
            ScanResponse resp = db.scan(req);

            List<MQMessageItem> out = new ArrayList<>();
            for (Map<String, AttributeValue> i : resp.items()) {
                MQMessageItem item = mapItem(i);
                if (item != null && !isProcessed(db, item.getCorrelationid())) {
                    out.add(item);
                }
            }
            return out;
        }
    }

    private MQMessageItem mapItem(Map<String, AttributeValue> i) {
        try {
            MQMessageItem m = new MQMessageItem();
            m.setId(getS(i, "id"));
            m.setProgramname(getS(i, "programname"));
            m.setCorrelationid(getS(i, "correlationid"));
            m.setMessage1(getS(i, "message1"));
            m.setMessage2(getS(i, "message2"));

            if (m.getCorrelationid() == null || m.getMessage1() == null || m.getMessage2() == null) {
                log.warn("Skipping malformed item: {}", i);
                return null;
            }
            return m;
        } catch (Exception e) {
            log.warn("Error mapping item: {}", e.getMessage());
            return null;
        }
    }

    private String getS(Map<String, AttributeValue> i, String key) {
        AttributeValue v = i.get(key);
        return v == null ? null : v.s();
    }

    public boolean isProcessed(DynamoDbClient db, String correlationId) {
        try {
            GetItemRequest req = GetItemRequest.builder()
                    .tableName(props.getProcessedTable())
                    .key(Collections.singletonMap("correlationid",
                            AttributeValue.builder().s(correlationId).build()))
                    .build();
            GetItemResponse resp = db.getItem(req);
            return resp.hasItem();
        } catch (ResourceNotFoundException rnfe) {
            log.error("ProcessedTracker table not found: {}", props.getProcessedTable());
            return false;
        } catch (Exception e) {
            log.warn("Error reading ProcessedTracker: {}", e.getMessage());
            return false;
        }
    }

    public void markProcessed(String correlationId) {
        try (DynamoDbClient db = client()) {
            Map<String, AttributeValue> item = new HashMap<>();
            item.put("correlationid", AttributeValue.builder().s(correlationId).build());
            item.put("processedAt", AttributeValue.builder().s(new java.util.Date().toString()).build());
            PutItemRequest req = PutItemRequest.builder()
                    .tableName(props.getProcessedTable())
                    .item(item).build();
            db.putItem(req);
        } catch (ResourceNotFoundException rnfe) {
            log.error("ProcessedTracker table not found: {}", props.getProcessedTable());
        } catch (Exception e) {
            log.warn("Error writing ProcessedTracker: {}", e.getMessage());
        }
    }
}
