package com.example.mqmonitor.reporting;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.example.mqmonitor.config.AppProperties;
import com.example.mqmonitor.model.ComparisonResult;
import com.example.mqmonitor.model.MQMessageItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class ReportService {
    private static final Logger log = LoggerFactory.getLogger(ReportService.class);
    private final AppProperties props;

    public ReportService(AppProperties props) {
        this.props = props;
    }

    public static class ReportResult {
        public final File file;
        public final String filename;
        public ReportResult(File f, String name){ this.file = f; this.filename = name; }
    }

    public ExtentReports create(StringBuilder filenameHolder) {
        try {
            String ts = new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
            File dir = new File(props.getReportDir());
            if (!dir.exists()) dir.mkdirs();
            String filename = "mq-compare-" + ts + ".html";
            filenameHolder.append(filename);
            File out = new File(dir, filename);
            ExtentSparkReporter reporter = new ExtentSparkReporter(out);
            ExtentReports extent = new ExtentReports();
            extent.attachReporter(reporter);
            return extent;
        } catch (Exception e) {
            log.error("Failed to create Extent report: {}", e.getMessage());
            return null;
        }
    }

    public ReportResult finalizeReport(ExtentReports extent, String filename) {
        if (extent != null) extent.flush();
        File out = new File(props.getReportDir(), filename);
        return new ReportResult(out, filename);
    }

    public void logRecord(ExtentReports extent, MQMessageItem item, ComparisonResult result) {
        if (extent == null) return;
        ExtentTest test = extent.createTest("CorrelationId: " + item.getCorrelationid());
        test.info("Program: " + item.getProgramname());
        switch (result.getStatus()) {
            case MATCH -> test.pass("✅ Messages match");
            case MISMATCH -> test.fail("❌ Messages differ:\n" + result.getDetails());
            case ERROR -> test.warning("⚠️ Error: " + result.getDetails());
        }
    }

    public void logError(ExtentReports extent, String context, String error) {
        if (extent == null) return;
        extent.createTest(context).warning(error);
    }
}
