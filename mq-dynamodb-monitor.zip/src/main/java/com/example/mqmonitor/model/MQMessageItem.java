package com.example.mqmonitor.model;

public class MQMessageItem {
    private String id;
    private String programname;
    private String correlationid;
    private String message1;
    private String message2;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getProgramname() { return programname; }
    public void setProgramname(String programname) { this.programname = programname; }
    public String getCorrelationid() { return correlationid; }
    public void setCorrelationid(String correlationid) { this.correlationid = correlationid; }
    public String getMessage1() { return message1; }
    public void setMessage1(String message1) { this.message1 = message1; }
    public String getMessage2() { return message2; }
    public void setMessage2(String message2) { this.message2 = message2; }
}
