package com.example.mqmonitor.model;

public class ComparisonResult {
    public enum Status { MATCH, MISMATCH, ERROR }
    private final Status status;
    private final String details;

    public ComparisonResult(Status status, String details) {
        this.status = status;
        this.details = details;
    }
    public static ComparisonResult match() { return new ComparisonResult(Status.MATCH, ""); }
    public static ComparisonResult mismatch(String details) { return new ComparisonResult(Status.MISMATCH, details); }
    public static ComparisonResult error(String details) { return new ComparisonResult(Status.ERROR, details); }
    public Status getStatus() { return status; }
    public String getDetails() { return details; }
}
