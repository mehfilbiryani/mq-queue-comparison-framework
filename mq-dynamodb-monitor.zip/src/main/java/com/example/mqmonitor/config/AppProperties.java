package com.example.mqmonitor.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;
import java.util.List;

@Validated
@ConfigurationProperties(prefix = "app")
public class AppProperties {
    private String awsRegion = "ap-south-1";
    private String dynamoTable = "MQMessages";
    private String processedTable = "ProcessedTracker";
    private int dynamoPageSize = 200;

    private List<String> ignoreFields;
    private List<String> ignoreXmlXpaths;

    private String cron = "0 0/10 * * * *";

    private String reportDir = "reports";
    private boolean s3UploadEnabled = false;
    private String s3Bucket;
    private String s3Prefix = "reports/";
    private boolean s3PublicUrl = false;
    private int s3PresignMinutes = 120;

    private boolean emailEnabled = false;
    private java.util.List<String> emailRecipients;

    private boolean teamsEnabled = false;
    private String teamsWebhookUrl;

    // getters/setters
    public String getAwsRegion() { return awsRegion; }
    public void setAwsRegion(String awsRegion) { this.awsRegion = awsRegion; }
    public String getDynamoTable() { return dynamoTable; }
    public void setDynamoTable(String dynamoTable) { this.dynamoTable = dynamoTable; }
    public String getProcessedTable() { return processedTable; }
    public void setProcessedTable(String processedTable) { this.processedTable = processedTable; }
    public int getDynamoPageSize() { return dynamoPageSize; }
    public void setDynamoPageSize(int dynamoPageSize) { this.dynamoPageSize = dynamoPageSize; }
    public List<String> getIgnoreFields() { return ignoreFields; }
    public void setIgnoreFields(List<String> ignoreFields) { this.ignoreFields = ignoreFields; }
    public List<String> getIgnoreXmlXpaths() { return ignoreXmlXpaths; }
    public void setIgnoreXmlXpaths(List<String> ignoreXmlXpaths) { this.ignoreXmlXpaths = ignoreXmlXpaths; }
    public String getCron() { return cron; }
    public void setCron(String cron) { this.cron = cron; }
    public String getReportDir() { return reportDir; }
    public void setReportDir(String reportDir) { this.reportDir = reportDir; }
    public boolean isS3UploadEnabled() { return s3UploadEnabled; }
    public void setS3UploadEnabled(boolean s3UploadEnabled) { this.s3UploadEnabled = s3UploadEnabled; }
    public String getS3Bucket() { return s3Bucket; }
    public void setS3Bucket(String s3Bucket) { this.s3Bucket = s3Bucket; }
    public String getS3Prefix() { return s3Prefix; }
    public void setS3Prefix(String s3Prefix) { this.s3Prefix = s3Prefix; }
    public boolean isS3PublicUrl() { return s3PublicUrl; }
    public void setS3PublicUrl(boolean s3PublicUrl) { this.s3PublicUrl = s3PublicUrl; }
    public int getS3PresignMinutes() { return s3PresignMinutes; }
    public void setS3PresignMinutes(int s3PresignMinutes) { this.s3PresignMinutes = s3PresignMinutes; }
    public boolean isEmailEnabled() { return emailEnabled; }
    public void setEmailEnabled(boolean emailEnabled) { this.emailEnabled = emailEnabled; }
    public java.util.List<String> getEmailRecipients() { return emailRecipients; }
    public void setEmailRecipients(java.util.List<String> emailRecipients) { this.emailRecipients = emailRecipients; }
    public boolean isTeamsEnabled() { return teamsEnabled; }
    public void setTeamsEnabled(boolean teamsEnabled) { this.teamsEnabled = teamsEnabled; }
    public String getTeamsWebhookUrl() { return teamsWebhookUrl; }
    public void setTeamsWebhookUrl(String teamsWebhookUrl) { this.teamsWebhookUrl = teamsWebhookUrl; }
}
