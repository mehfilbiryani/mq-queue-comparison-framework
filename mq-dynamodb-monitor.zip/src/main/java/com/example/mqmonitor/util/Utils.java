package com.example.mqmonitor.util;

public class Utils {
    public static boolean looksLikeJson(String s) {
        if (s == null) return false;
        String t = s.trim();
        return t.startsWith("{") || t.startsWith("[");
    }
    public static boolean looksLikeXml(String s) {
        if (s == null) return false;
        String t = s.trim();
        return t.startsWith("<");
    }
}
