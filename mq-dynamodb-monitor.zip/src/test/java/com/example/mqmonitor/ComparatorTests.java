package com.example.mqmonitor;

import com.example.mqmonitor.compare.JsonComparator;
import com.example.mqmonitor.compare.XmlComparator;
import com.example.mqmonitor.model.ComparisonResult;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class ComparatorTests {

    @Test
    void jsonMatchIgnoringFields() {
        JsonComparator jc = new JsonComparator();
        String a = "{\"id\":1,\"timestamp\":\"t1\",\"payload\":{\"x\":\"A\",\"y\":1}}";
        String b = "{\"id\":1,\"timestamp\":\"t2\",\"payload\":{\"x\":\"A\",\"y\":1}}";
        ComparisonResult r = jc.compareJson(a,b, List.of("timestamp"));
        assertEquals(ComparisonResult.Status.MATCH, r.getStatus());
    }

    @Test
    void jsonMismatch() {
        JsonComparator jc = new JsonComparator();
        String a = "{\"id\":1,\"payload\":{\"x\":\"A\",\"y\":1}}";
        String b = "{\"id\":1,\"payload\":{\"x\":\"B\",\"y\":1}}";
        ComparisonResult r = jc.compareJson(a,b, List.of());
        assertEquals(ComparisonResult.Status.MISMATCH, r.getStatus());
    }

    @Test
    void xmlMatchIgnoringPath() {
        XmlComparator xc = new XmlComparator();
        String a = "<root><ts>1</ts><data><x>A</x></data></root>";
        String b = "<root><ts>2</ts><data><x>A</x></data></root>";
        ComparisonResult r = xc.compareXml(a,b, List.of("/root/ts"));
        assertEquals(ComparisonResult.Status.MATCH, r.getStatus());
    }
}
